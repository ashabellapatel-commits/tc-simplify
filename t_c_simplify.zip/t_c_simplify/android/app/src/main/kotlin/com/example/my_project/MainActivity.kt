package com.company.aiassistant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
