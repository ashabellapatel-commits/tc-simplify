import '/flutter_flow/flutter_flow_util.dart';
import 'loading_widget_widget.dart' show LoadingWidgetWidget;
import 'package:flutter/material.dart';

class LoadingWidgetModel extends FlutterFlowModel<LoadingWidgetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
