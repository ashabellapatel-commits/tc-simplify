import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCGLq6abdTPjUGlEucNn23Cb51pTmwbJX0",
            authDomain: "streaming-ai-assistant.firebaseapp.com",
            projectId: "streaming-ai-assistant",
            storageBucket: "streaming-ai-assistant.appspot.com",
            messagingSenderId: "559625535756",
            appId: "1:559625535756:web:9f2e2672911b04eb3a4929"));
  } else {
    await Firebase.initializeApp();
  }
}
