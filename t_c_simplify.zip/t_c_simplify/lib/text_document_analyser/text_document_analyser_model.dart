import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'text_document_analyser_widget.dart' show TextDocumentAnalyserWidget;
import 'package:flutter/material.dart';

class TextDocumentAnalyserModel
    extends FlutterFlowModel<TextDocumentAnalyserWidget> {
  ///  State fields for stateful widgets in this page.

  bool isDataUploading_uploadDataRlt = false;
  List<FFUploadedFile> uploadedLocalFiles_uploadDataRlt = [];

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  bool isDataUploading_uploadData4v9 = false;
  FFUploadedFile uploadedLocalFile_uploadData4v9 =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
